package com.nova.space

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { NovaApp() } }
}

private val bg = Color(0xFF050A16)
private val glass = Color(0xC9101C32)
private val cyan = Color(0xFF75C9FF)
private val dim = Color(0xFFB8C7DA)

@Composable fun NovaApp() {
    var page by remember { mutableStateOf("Dashboard") }
    var missionCount by remember { mutableIntStateOf(0) }
    var elapsed by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1000); elapsed++ } }
    val nav = listOf("Dashboard", "Missions", "Star Map", "Fleet", "Research", "Log")
    val icons = listOf(Icons.Default.Home, Icons.Default.Flag, Icons.Default.Public, Icons.Default.RocketLaunch, Icons.Default.Science, Icons.Default.ListAlt)
    MaterialTheme(colorScheme = darkColorScheme(background=bg, surface=glass, primary=cyan)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A142B), bg, Color(0xFF03050D))))) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal=12.dp, vertical=10.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text("✦ NOVA", fontSize=24.sp, fontWeight=FontWeight.Black, color=cyan, letterSpacing=2.sp, modifier=Modifier.padding(end=14.dp))
                    nav.forEachIndexed { i, item ->
                        TextButton(onClick={page=item}, modifier=Modifier.padding(end=2.dp)) {
                            Icon(icons[i], null, tint=if(page==item) cyan else dim, modifier=Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp)); Text(item, color=if(page==item) Color.White else dim, fontSize=12.sp)
                        }
                    }
                }
                when(page) {
                    "Dashboard" -> Dashboard(elapsed, missionCount, onLaunch={page="Missions"}, onFleet={page="Fleet"}, onMissionToggle={missionCount++})
                    "Missions" -> Missions(onToggle={missionCount++})
                    "Star Map" -> StarMap()
                    "Fleet" -> Fleet()
                    "Research" -> Research()
                    else -> LogPage(missionCount, elapsed)
                }
            }
        }
    }
}

@Composable fun Dashboard(seconds:Int, completed:Int, onLaunch:()->Unit, onFleet:()->Unit, onMissionToggle:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=16.dp)) {
        Spacer(Modifier.height(8.dp))
        Hero(onLaunch,onFleet)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Stat("MISSIONS", completed.toString()); Stat("MISSION CLOCK", "%02d:%02d:%02d".format(seconds/3600,(seconds/60)%60,seconds%60)); Stat("SYSTEM", "ONLINE") }
        Spacer(Modifier.height(18.dp)); Text("Mission Control", color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(bottom=14.dp)) {
            items(listOf("NOVA-01 · Explorer","Lunar Outpost","Star Map","Active Missions","Asteroid Watch")) { title ->
                MiniCard(title, when(title){ "NOVA-01 · Explorer"->"🚀"; "Lunar Outpost"->"🌑"; "Star Map"->"✦"; "Active Missions"->"☑"; else->"☄" }, when(title){"NOVA-01 · Explorer"->"Ship status: ready";"Lunar Outpost"->"Destination · Moon";"Star Map"->"128 systems mapped";"Active Missions"->"Tap to mark progress";else->"Tracking object"},onMissionToggle)
            }
        }
        Text("Flight telemetry", color=Color.White, fontSize=19.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp)); GlassPanel { Column { Text("ORBITAL STATUS",color=cyan,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp); Spacer(Modifier.height(8.dp)); Text("Earth orbit · Stable",color=Color.White,fontSize=18.sp); Text("Altitude 408 km    Velocity 7.66 km/s",color=dim,fontSize=13.sp) } }
        Spacer(Modifier.height(28.dp))
    }
}
@Composable fun Hero(onLaunch:()->Unit,onFleet:()->Unit) {
    Box(Modifier.fillMaxWidth().height(400.dp).clip(RoundedCornerShape(26.dp)).border(1.dp,Color(0x443C91C8),RoundedCornerShape(26.dp))) {
        Image(painterResource(R.drawable.nova_hero),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xDD050B1B),Color(0x33050B1B),Color.Transparent))))
        Column(Modifier.align(Alignment.CenterStart).padding(22.dp).widthIn(max=370.dp)) {
            Text("● SYSTEM ONLINE",color=Color(0xFF77F0CE),fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
            Spacer(Modifier.height(14.dp)); Text("EXPLORE.\nDISCOVER.\nENDURE.",fontSize=34.sp,lineHeight=37.sp,fontWeight=FontWeight.Black,color=Color.White,letterSpacing=1.sp)
            Spacer(Modifier.height(10.dp)); Text("Navigate the unknown, satisfy new worlds, and push the boundaries of human presence.",color=Color(0xFFE0E8F4),fontSize=13.sp,lineHeight=18.sp)
            Spacer(Modifier.height(18.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Button(onClick=onLaunch,colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Color(0xFF10182A))) { Icon(Icons.Default.RocketLaunch,null); Spacer(Modifier.width(6.dp)); Text("Launch mission") }; OutlinedButton(onClick=onFleet) { Icon(Icons.Default.Groups,null); Spacer(Modifier.width(5.dp)); Text("View fleet") } }
        }
    }
}
@Composable fun Stat(label:String,value:String) { GlassPanel(Modifier.weight(1f)) { Column { Text(label,color=dim,fontSize=9.sp,letterSpacing=1.sp); Spacer(Modifier.height(4.dp)); Text(value,color=Color.White,fontWeight=FontWeight.Bold,fontSize=15.sp) } } }
@Composable fun MiniCard(title:String,emoji:String,desc:String,onClick:()->Unit) { GlassPanel(Modifier.width(235.dp).height(170.dp).clickable(onClick)) { Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.SpaceBetween) { Text(emoji,fontSize=36.sp); Text(title,color=Color.White,fontWeight=FontWeight.Bold,fontSize=14.sp); Text(desc,color=dim,fontSize=12.sp); Text("OPEN  ↗",color=cyan,fontSize=10.sp,fontWeight=FontWeight.Bold) } } }
@Composable fun GlassPanel(modifier:Modifier=Modifier,content:@Composable ()->Unit) { Column(modifier.padding(0.dp).clip(RoundedCornerShape(17.dp)).background(glass).border(1.dp,Color(0x263E9AC9),RoundedCornerShape(17.dp)).padding(15.dp)) { content() } }
@Composable fun Missions(onToggle:()->Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) { PageTitle("MISSIONS","Mission objectives and expedition assignments") ; listOf("Explore the Alpha system · 500 XP","Analyze quantum anomaly · 750 XP","Visit Kepler-62f · 1,000 XP","Survey lunar south pole · 600 XP").forEach { MissionRow(it,onToggle) } } }
@Composable fun MissionRow(text:String,onToggle:()->Unit) { var checked by remember { mutableStateOf(false) }; GlassPanel(Modifier.fillMaxWidth().padding(bottom=9.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(checked,onCheckedChange={checked=it;if(it)onToggle()},colors=CheckboxDefaults.colors(checkedColor=cyan)); Column(Modifier.weight(1f)) { Text(text,color=Color.White,fontWeight=FontWeight.SemiBold); Text(if(checked)"COMPLETED" else "AVAILABLE",color=if(checked)Color(0xFF71E6C2) else dim,fontSize=10.sp) } } } }
@Composable fun StarMap() { Column(Modifier.fillMaxSize().padding(16.dp)) { PageTitle("STAR MAP","Exploration sectors · Schematic view"); GlassPanel(Modifier.fillMaxWidth().height(420.dp)) { Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) { Text("✦      ·       ✧\n     ✦     ◉\n  ·       ✦       ·\n        ✧       ✦",fontSize=42.sp,color=cyan,lineHeight=65.sp); Text("SOL SYSTEM     •     ALPHA CENTAURI     •     KEPLER",Modifier.align(Alignment.BottomCenter),color=dim,fontSize=10.sp) } } } }
@Composable fun Fleet() { Column(Modifier.fillMaxSize().padding(16.dp)) { PageTitle("FLEET","Vehicle readiness and crew status"); listOf("NOVA-01 Explorer · READY","NOVA-02 Voyager · IN MAINTENANCE","NOVA-03 Horizon · STANDBY").forEach { GlassPanel(Modifier.fillMaxWidth().padding(bottom=10.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Text("🚀",fontSize=30.sp); Spacer(Modifier.width(12.dp)); Column { Text(it,color=Color.White,fontWeight=FontWeight.Bold); Text("Crew · 4   |   Range · 12 AU",color=dim,fontSize=12.sp) } } } } } }
@Composable fun Research() { Column(Modifier.fillMaxSize().padding(16.dp)) { PageTitle("RESEARCH","Science programs and discovery logs"); listOf("Exoplanet atmospheres","Quantum propulsion concepts","Deep-space navigation","Life-support systems","Gravitational-wave observatories").forEach { GlassPanel(Modifier.fillMaxWidth().padding(bottom=9.dp)) { Text("🧪  $it",color=Color.White,fontWeight=FontWeight.Bold); Text("Program status · Collecting data",color=dim,fontSize=12.sp) } } } }
@Composable fun LogPage(count:Int,time:Int) { Column(Modifier.fillMaxSize().padding(16.dp)) { PageTitle("MISSION LOG","Local activity summary"); GlassPanel(Modifier.fillMaxWidth()) { Text("Mission progress actions: $count",color=Color.White); Text("Session time: ${time/60} min ${time%60} sec",color=dim); Text("System initialized successfully.",color=cyan) } } }
@Composable fun PageTitle(title:String,subtitle:String) { Text(title,color=Color.White,fontSize=27.sp,fontWeight=FontWeight.Black,letterSpacing=2.sp); Spacer(Modifier.height(5.dp)); Text(subtitle,color=dim,fontSize=13.sp); Spacer(Modifier.height(18.dp)) }
'''
cat > /mnt/data/NOVA_Android/README.md <<'EOF'
# NOVA Android native project

This is a native Android app project built with Kotlin + Jetpack Compose. It does not use HTML or WebView.

## Build APK
1. Install Android Studio (current stable) on a PC/Mac.
2. Open this folder (`NOVA_Android`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose Build > Build APK(s).
5. The debug APK is generated under `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, min Android 8.0 (API 26).
