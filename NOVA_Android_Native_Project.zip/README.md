# NOVA Android — Native starter project

This is an Android-native Kotlin + Jetpack Compose starter (not a WebView or HTML app).

## Build
1. Install Android Studio.
2. Open this folder as a project.
3. Allow Gradle sync to finish. The build requires internet for Gradle dependency downloads.
4. Select a device or emulator and press Run.
5. To build an APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
   The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Included screens
- Space-themed dashboard
- Science library with search
- Topic overview/chapter list
- MRU simulator (velocity/time sliders)
- Quanta demo chat (not connected to an AI service)
- Explorer profile panel

## Limitations
This starter project is native Android source, but it is not a finished store-ready app.
Chapter reader content, persistence, AI integration, additional simulators, and full testing remain to be implemented.
