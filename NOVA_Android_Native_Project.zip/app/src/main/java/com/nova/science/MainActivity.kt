package com.nova.science

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

private val Night = Color(0xFF070B18)
private val Panel = Color(0xFF111A2D)
private val Cyan = Color(0xFF52D9FF)
private val Violet = Color(0xFF8D73FF)
private val Muted = Color(0xFF92A4C4)

@Composable
fun NovaApp() {
    var selected by remember { mutableStateOf("Inicio") }
    var selectedTopic by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    val topics = listOf(
        "Física" to "Movimiento, fuerzas, energía, ondas y leyes fundamentales del universo.",
        "Astrofísica" to "Estrellas, galaxias, agujeros negros y evolución cósmica.",
        "Física cuántica" to "Cuantización, superposición, incertidumbre y partículas.",
        "Relatividad" to "Espacio-tiempo, gravedad, relatividad especial y general.",
        "Matemáticas" to "Álgebra, cálculo, geometría, estadística y lógica.",
        "Química" to "Materia, enlaces, reacciones, estructura atómica y laboratorio.",
        "Biología" to "Células, genética, evolución, organismos y ecosistemas.",
        "Neurociencia" to "Cerebro, neuronas, memoria, percepción y aprendizaje.",
        "Tecnología e IA" to "Computación, robótica, algoritmos e inteligencia artificial."
    )
    MaterialTheme {
        Box(Modifier.fillMaxSize().background(Night)) {
            Starfield()
            Column(Modifier.fillMaxSize()) {
                Header()
                if (selectedTopic != null) {
                    TopicDetail(selectedTopic!!, onBack = { selectedTopic = null })
                } else {
                    when (selected) {
                        "Inicio" -> HomeScreen(onNavigate = { selected = it }, onTopic = { selectedTopic = it })
                        "Academia" -> AcademyScreen(topics, query, { query = it }, onTopic = { selectedTopic = it })
                        "Laboratorio" -> LabScreen()
                        "Quanta" -> QuantaScreen()
                        "Perfil" -> ProfileScreen()
                    }
                }
                Spacer(Modifier.weight(1f))
                BottomNav(selected) { selected = it }
            }
        }
    }
}

@Composable
fun Starfield() {
    Canvas(Modifier.fillMaxSize()) {
        val seed = 24
        for (i in 0 until 90) {
            val x = ((i * 73 + seed * 19) % 997) / 997f * size.width
            val y = ((i * 137 + seed * 11) % 991) / 991f * size.height
            val r = if (i % 8 == 0) 2.1f else 1f
            drawCircle(if (i % 7 == 0) Cyan.copy(.35f) else Color.White.copy(.22f), r, androidx.compose.ui.geometry.Offset(x,y))
        }
        drawCircle(Violet.copy(alpha=.05f), size.width*.28f, androidx.compose.ui.geometry.Offset(size.width*.8f, size.height*.12f))
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp, vertical=14.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Cyan, Violet))), contentAlignment=Alignment.Center) {
            Icon(Icons.Default.Public, contentDescription=null, tint=Night)
        }
        Column(Modifier.padding(start=10.dp)) {
            Text("NOVA", color=Color.White, fontWeight=FontWeight.Black, fontSize=20.sp, letterSpacing=3.sp)
            Text("SCIENCE UNIVERSE", color=Cyan, fontSize=9.sp, letterSpacing=2.sp)
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(38.dp).clip(CircleShape).background(Panel).border(1.dp, Cyan.copy(.25f), CircleShape), contentAlignment=Alignment.Center) {
            Icon(Icons.Default.NotificationsNone, contentDescription="Notificaciones", tint=Color.White, modifier=Modifier.size(19.dp))
        }
    }
}

@Composable
fun HomeScreen(onNavigate:(String)->Unit, onTopic:(String)->Unit) {
    LazyColumn(contentPadding=PaddingValues(horizontal=18.dp, vertical=10.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item {
            Text("CENTRO DE MANDO", color=Cyan, fontSize=10.sp, letterSpacing=2.sp, fontWeight=FontWeight.Bold)
            Text("Explora lo\ndesconocido.", color=Color.White, fontSize=31.sp, lineHeight=36.sp, fontWeight=FontWeight.Bold)
            Text("Tu universo de conocimiento comienza aquí.", color=Muted, fontSize=13.sp)
        }
        item {
            Card(shape=RoundedCornerShape(24.dp), colors=CardDefaults.cardColors(containerColor=Panel), modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("MISIÓN DEL DÍA", color=Cyan, fontSize=10.sp, letterSpacing=2.sp, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.AutoAwesome, contentDescription=null, tint=Violet)
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("El movimiento\ndel universo", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Bold)
                    Text("Descubre cómo se describe el movimiento usando el modelo del MRU.", color=Muted, fontSize=13.sp)
                    Spacer(Modifier.height(14.dp))
                    Button(onClick={onTopic("Movimiento rectilíneo uniforme (MRU)")}, colors=ButtonDefaults.buttonColors(containerColor=Cyan), shape=RoundedCornerShape(12.dp)) {
                        Text("Comenzar misión", color=Night, fontWeight=FontWeight.Bold)
                        Icon(Icons.Default.ArrowForward, null, tint=Night)
                    }
                }
            }
        }
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("UNIVERSO CIENTÍFICO", color=Color.White, fontWeight=FontWeight.Bold, fontSize=17.sp)
                Spacer(Modifier.weight(1f))
                Text("Ver todo", color=Cyan, modifier=Modifier.clickable{onNavigate("Academia")}, fontSize=12.sp)
            }
        }
        item {
            Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                TopicCard("Física", "Las leyes que gobiernan la realidad", "⚛", Cyan) { onTopic("Física") }
                TopicCard("Astrofísica", "Explora estrellas y galaxias", "✦", Violet) { onTopic("Astrofísica") }
                TopicCard("Física cuántica", "El universo a escala microscópica", "◈", Color(0xFF67E8B5)) { onTopic("Física cuántica") }
            }
        }
        item {
            Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(20.dp), modifier=Modifier.fillMaxWidth().clickable{onNavigate("Quanta")}) {
                Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Cyan.copy(.12f)), contentAlignment=Alignment.Center) { Icon(Icons.Default.Psychology, null, tint=Cyan, modifier=Modifier.size(28.dp)) }
                    Column(Modifier.padding(start=12.dp)) {
                        Text("QUANTA · TUTOR VIRTUAL", color=Cyan, fontSize=10.sp, fontWeight=FontWeight.Bold)
                        Text("¿Qué quieres descubrir hoy?", color=Color.White, fontWeight=FontWeight.SemiBold)
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ChevronRight, null, tint=Muted)
                }
            }
        }
    }
}

@Composable
fun TopicCard(title:String, subtitle:String, glyph:String, accent:Color, onClick:()->Unit) {
    Card(onClick=onClick, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp), modifier=Modifier.fillMaxWidth()) {
        Row(Modifier.padding(15.dp), verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(.12f)), contentAlignment=Alignment.Center) {
                Text(glyph, color=accent, fontSize=25.sp, fontWeight=FontWeight.Bold)
            }
            Column(Modifier.padding(start=12.dp)) {
                Text(title, color=Color.White, fontWeight=FontWeight.Bold)
                Text(subtitle, color=Muted, fontSize=11.sp)
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null, tint=Muted)
        }
    }
}

@Composable
fun AcademyScreen(topics:List<Pair<String,String>>, query:String, onQuery:(String)->Unit, onTopic:(String)->Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal=18.dp)) {
        Text("NOVA ACADEMY", color=Cyan, fontSize=10.sp, letterSpacing=2.sp, fontWeight=FontWeight.Bold)
        Text("Biblioteca", color=Color.White, fontSize=28.sp, fontWeight=FontWeight.Bold)
        OutlinedTextField(value=query, onValueChange=onQuery, modifier=Modifier.fillMaxWidth().padding(vertical=12.dp), placeholder={Text("Buscar un universo...", color=Muted)}, leadingIcon={Icon(Icons.Default.Search,null,tint=Cyan)}, singleLine=true, colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Cyan, unfocusedBorderColor=Muted.copy(.4f), focusedTextColor=Color.White, unfocusedTextColor=Color.White))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(bottom=12.dp)) {
            items(topics.filter{it.first.contains(query, true) || it.second.contains(query,true)}) { item ->
                TopicCard(item.first, item.second, "✧", Cyan) { onTopic(item.first) }
            }
        }
    }
}

@Composable
fun TopicDetail(topic:String, onBack:()->Unit) {
    val chapters = when(topic) {
        "Física" -> listOf("Introducción a la física","Magnitudes y unidades","Movimiento y cinemática","MRU","MRUA","Leyes de Newton","Trabajo y energía","Cantidad de movimiento","Gravitación","Ondas","Electricidad","Magnetismo","Termodinámica","Óptica","Física moderna")
        "Astrofísica" -> listOf("El universo","Sistema solar","Estrellas","Evolución estelar","Galaxias","Nebulosas","Agujeros negros","Materia oscura","Cosmología")
        "Física cuántica" -> listOf("Introducción cuántica","Dualidad onda-partícula","Superposición","Principio de incertidumbre","Función de onda","Entrelazamiento","Efecto túnel","Aplicaciones")
        else -> listOf("Introducción","Conceptos fundamentales","Historia y desarrollo","Principios y leyes","Modelos y teorías","Aplicaciones","Ejercicios","Desafíos")
    }
    LazyColumn(contentPadding=PaddingValues(horizontal=18.dp, vertical=8.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Text("‹  VOLVER", color=Cyan, modifier=Modifier.clickable{onBack()}, fontWeight=FontWeight.Bold, fontSize=12.sp)
            Spacer(Modifier.height(12.dp))
            Text("NOVA ACADEMY / LIBRO", color=Muted, fontSize=10.sp, letterSpacing=2.sp)
            Text(topic, color=Color.White, fontSize=29.sp, fontWeight=FontWeight.Bold)
            Text("Selecciona un capítulo para comenzar tu exploración.", color=Muted, fontSize=13.sp)
        }
        items(chapters) { chapter ->
            Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(16.dp), modifier=Modifier.fillMaxWidth().clickable { }) {
                Row(Modifier.padding(15.dp), verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(36.dp).clip(CircleShape).background(Cyan.copy(.12f)), contentAlignment=Alignment.Center) { Text("${chapters.indexOf(chapter)+1}", color=Cyan, fontWeight=FontWeight.Bold) }
                    Text(chapter, color=Color.White, modifier=Modifier.padding(start=12.dp).weight(1f), fontWeight=FontWeight.SemiBold)
                    Icon(Icons.Default.LockOpen, null, tint=Muted, modifier=Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun LabScreen() {
    var velocity by remember { mutableFloatStateOf(5f) }
    var time by remember { mutableFloatStateOf(8f) }
    val distance=velocity*time
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("NOVA LAB", color=Cyan, fontSize=10.sp, letterSpacing=2.sp, fontWeight=FontWeight.Bold)
        Text("Laboratorio", color=Color.White, fontSize=28.sp, fontWeight=FontWeight.Bold)
        Text("Simuladores interactivos", color=Muted)
        Spacer(Modifier.height(20.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("SIMULADOR · MRU", color=Cyan, fontWeight=FontWeight.Bold, fontSize=11.sp)
                Text("Movimiento rectilíneo uniforme", color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text("Velocidad: ${velocity.toInt()} m/s", color=Color.White)
                Slider(velocity, {velocity=it}, valueRange=0f..30f, colors=SliderDefaults.colors(thumbColor=Cyan, activeTrackColor=Cyan))
                Text("Tiempo: ${time.toInt()} s", color=Color.White)
                Slider(time, {time=it}, valueRange=0f..60f, colors=SliderDefaults.colors(thumbColor=Violet, activeTrackColor=Violet))
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Night).padding(16.dp)) {
                    Column {
                        Text("DISTANCIA RECORRIDA", color=Muted, fontSize=10.sp, letterSpacing=1.sp)
                        Text("%.1f m".format(distance), color=Cyan, fontSize=32.sp, fontWeight=FontWeight.Black)
                        Text("d = v × t = ${velocity.toInt()} × ${time.toInt()}", color=Color.White, fontSize=12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("PRÓXIMOS LABORATORIOS", color=Violet, fontWeight=FontWeight.Bold, fontSize=11.sp)
                Text("Órbitas · Gravedad · Ondas · Circuitos", color=Color.White, modifier=Modifier.padding(top=8.dp))
                Text("Módulos adicionales en desarrollo.", color=Muted, fontSize=12.sp)
            }
        }
    }
}

@Composable
fun QuantaScreen() {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("¡Hola! Soy Quanta, tu compañero de exploración científica. Pregúntame sobre física, universo, matemáticas o cualquier ciencia. En esta versión puedo mostrarte una guía de estudio básica.") }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("NOVA INTELLIGENCE", color=Cyan, fontSize=10.sp, letterSpacing=2.sp, fontWeight=FontWeight.Bold)
        Text("Quanta", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.Bold)
        Text("Tu compañero científico", color=Muted)
        Spacer(Modifier.height(16.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(22.dp), modifier=Modifier.weight(1f)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Cyan.copy(.15f)), contentAlignment=Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint=Cyan) }
                    Column(Modifier.padding(start=10.dp)) {
                        Text("QUANTA", color=Color.White, fontWeight=FontWeight.Bold)
                        Text("GUÍA DE APRENDIZAJE", color=Cyan, fontSize=9.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text(answer, color=Color.White, fontSize=14.sp, lineHeight=21.sp)
            }
        }
        OutlinedTextField(question, {question=it}, modifier=Modifier.fillMaxWidth().padding(top=12.dp), placeholder={Text("Escribe tu pregunta...", color=Muted)}, colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Cyan, unfocusedBorderColor=Muted.copy(.4f), focusedTextColor=Color.White, unfocusedTextColor=Color.White))
        Button(onClick={
            answer= if(question.isBlank()) "Escribe primero una pregunta para iniciar." else "Tu pregunta: $question\n\nPara aprender este tema, comienza identificando sus conceptos fundamentales, revisa las leyes o modelos relacionados y luego resuelve un ejemplo. Quanta aún funciona en modo demostración: esta versión no está conectada a un modelo de inteligencia artificial."
            question=""
        }, modifier=Modifier.fillMaxWidth().padding(top=8.dp), colors=ButtonDefaults.buttonColors(containerColor=Cyan), shape=RoundedCornerShape(12.dp)) {
            Text("Enviar a Quanta", color=Night, fontWeight=FontWeight.Bold)
            Icon(Icons.Default.Send, null, tint=Night)
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("NOVA PROFILE", color=Cyan, fontSize=10.sp, letterSpacing=2.sp, fontWeight=FontWeight.Bold)
        Text("Explorador", color=Color.White, fontSize=28.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(20.dp)) {
                Text("NIVEL 01", color=Cyan, fontWeight=FontWeight.Bold)
                Text("Cadete cósmico", color=Color.White, fontSize=22.sp)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(progress={0.28f}, color=Cyan, trackColor=Muted.copy(.15f), modifier=Modifier.fillMaxWidth())
                Text("280 / 1.000 XP", color=Muted, fontSize=12.sp, modifier=Modifier.padding(top=8.dp))
            }
        }
        Spacer(Modifier.height(12.dp))
        listOf("Temas completados" to "0","Mis favoritos" to "0","Mis notas de laboratorio" to "0","Mis logros" to "0").forEach {
            Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(15.dp), modifier=Modifier.fillMaxWidth().padding(vertical=4.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text(it.first, color=Color.White, modifier=Modifier.weight(1f))
                    Text(it.second, color=Cyan, fontWeight=FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun BottomNav(selected:String, onSelect:(String)->Unit) {
    val nav = listOf("Inicio" to Icons.Default.Home, "Academia" to Icons.Default.MenuBook, "Laboratorio" to Icons.Default.Science, "Quanta" to Icons.Default.Psychology, "Perfil" to Icons.Default.Person)
    Row(Modifier.fillMaxWidth().background(Color(0xEE0B1121)).padding(vertical=8.dp), horizontalArrangement=Arrangement.SpaceAround) {
        nav.forEach { (name, icon) ->
            val active = selected==name
            Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable{onSelect(name)}.padding(horizontal=8.dp, vertical=4.dp), horizontalAlignment=Alignment.Center) {
                Icon(icon, contentDescription=name, tint=if(active) Cyan else Muted, modifier=Modifier.size(21.dp))
                Text(name, color=if(active) Cyan else Muted, fontSize=9.sp, fontWeight=if(active) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}
